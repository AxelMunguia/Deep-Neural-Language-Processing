# Building a Chatbot with DNLP
# Dataset downloaded from https://www.cs.cornell.edu/~cristian/Cornell_Movie-Dialogs_Corpus.html

#%% Importing libraries 
import numpy as np
import tensorflow as tf
import re # Limpiar el dataset
import time
import string

#%% ######### PART 1 - DATA PREPROCESSING#######

# Dataset
lines = open('movie_lines.txt',encoding="utf-8",errors="ignore").read().split("\n")
conversations = open('movie_conversations.txt',encoding="utf-8",errors="ignore").read().split("\n")


# Creating a dictionary thath maps each line and its id
id2line = {}

for line in lines:
    _line = line.split(" +++$+++ ") # After the split you'll have 5 elements
    if len(_line)==5:
        id2line[_line[0]] = _line[4] # Get id and text

# Creating a dictionary of conversations

conversations_ids = []

for conversation in conversations[:-1]: # The last element is an empty space
    _conversation = conversation.split(" +++$+++ ")[-1][1:-1].replace("'","").replace(" ","")
    # Remove quotes, spaces, squares brackets
    conversations_ids.append(_conversation.split(",")) 
    
# Getting separately the questions and the answers 
questions = []
answers = []
for conversation in conversations_ids:
    for i in range(len(conversation)-1):
        questions.append(id2line[conversation[i]])
        answers.append(id2line[conversation[i+1]])
       
# Doing a first cleaning of the text
def clean_text(text):
    text = text.lower()
    text = re.sub(r"i'm", "i am",text)
    text = re.sub(r"\'re", " are",text)
    text = re.sub(r"\'s", " is",text)
    text = re.sub(r"\'ll", " will" ,text)
    text = re.sub(r"\'ve", " have" ,text)
    text = re.sub(r"\'d", " would", text)
    text = re.sub(r"won't", "will not" ,text)
    text = re.sub(r"can't", "can not" ,text)
    text = "".join([l for l in text if l not in string.punctuation and l not in string.digits])
    
    return text
 
    
#  Cleaning the questions
clean_questions = []

for question in questions:
    clean_questions.append(clean_text(question))


#  Cleaning the answers

clean_answers = []

for answer in answers:
    clean_answers.append(clean_text(answer))

# Filtering put the questions and answers that are too short or too long
short_questions = []
short_answers = []
i = 0
for question in clean_questions:
    if 2 <= len(question.split())<=25:
        short_questions.append(question)
        short_answers.append(clean_answers[i])
    i +=1 

# Filter now answers
clean_questions = []
clean_answers = []
i = 0
for answer in short_answers:
    if 2 <= len(answer.split())<=25:
        clean_answers.append(answer)
        clean_questions.append(short_questions[i])
    i +=1 
        
# Creating a dictionary that maps each word to its number of occureces
word2count = {} 
for question in clean_questions:
    for word in question.split():
#         if word not in word2count:
#             word2count[word] = 1
#         else:
#             word2count[word] += 1
       word2count[word] =  word2count.get(word,0)+1
            
# Creating a dictionary that maps each word to its number of occureces
for answer in clean_answers:
    for word in answer.split():
#         if word not in word2count:
#             word2count[word] = 1
#         else:
#             word2count[word] += 1
        word2count[word] =  word2count.get(word,0)+1


# Creating two dictionaries that map the questions words and the answers words to a unique integer
threshold_questions = 15
questionswords2int = {}
word_number = 0
for word, count in word2count.items():
    if count>=threshold_questions:
        questionswords2int[word]  = word_number
        word_number+=1
        
threshold_answers = 15       
answerswords2int = {}
word_number = 0
for word,count in word2count.items():
    if count>= threshold_answers:
        answerswords2int[word] = word_number
        word_number+=1
        
# Adding the last tokens to these two dictionaries
tokens = ["<PAD>","<EOS>","<OUT>","<SOS>"]

for token in tokens:
    questionswords2int[token] = len(questionswords2int)+1
    
    
for token in tokens:
    answerswords2int[token] = len(answerswords2int)+1

# Create the inverse dictionary of the answerwords2int dictionary

answerints2word = {w_i:w for w, w_i in answerswords2int.items()} # Inverse

# Adding the End of String token to the end of every answer

# clean_answers =  [clean_answers[i] +" "+tokens[1]  for i in range(len(clean_answers))]

for i in range(len(clean_answers)):
    clean_answers[i] += " "+tokens[1]

# Translating all the questions and the answers into the unique integers
# and replacing all the words that were filtered out by <OUT>
    
questions_into_int = []

for question in clean_questions:
    ints = []
    for word in question.split():
        if word not in questionswords2int:
            ints.append(questionswords2int["<OUT>"])
        else:
            ints.append(questionswords2int[word])
    questions_into_int.append(ints)


answers_into_int = []

for answer in clean_answers:
    ints = []
    for word in answer.split():
        if word not in answerswords2int:
            ints.append(answerswords2int["<OUT>"])
        else:
            ints.append(answerswords2int[word])
    answers_into_int.append(ints)


# Sorting questions and answers by the length of questions

sorted_clean_questions = []
sorted_clean_answers = []

for length in range(1,25+1): # Not to include long questions
    for i in enumerate(questions_into_int): # Takes elements as a tuple
        if len(i[1])==length:
            sorted_clean_questions.append(questions_into_int[i[0]]) # Takes de (number,quesions_into_int)
            sorted_clean_answers.append(answers_into_int[i[0]])
            
#%% ########### PART 2 - BUILDING THE SEQ2SEQ MODEL ############

# Creating placeholders for the inputs and the targets
            
def model_input(): 
    
    inputs = tf.placeholder(dtype = tf.int32, shape = [None,None],name="input")
    targets = tf.placeholder(dtype = tf.int32, shape = [None,None],name="targets")
    lr = tf.placeholder(dtype = tf.float32,name="learning_rate")
    keep_prob = tf.placeholder(dtype = tf.float32,name="keep_prob") # Parameter that controls the decay of  lr 
    
    return inputs,targets,lr,keep_prob
 
# Preprocessing the targets
    
def preprocess_targets(targets,word2int,batch_size): # Will return de preprocess version of these targets
    
    left_side = tf.fill([batch_size, 1],word2int["<SOS>"])
        # fill([2, 3], 9) ==> [[9, 9, 9]
         #                [9, 9, 9]]
    right_side  = tf.strided_slice(targets,[0,0],[batch_size,-1],[1,1]) # Take all of them except the last one # No entiendo
    
    preprocessed_targets = tf.concat([left_side,right_side],axis=1)
    
    return preprocessed_targets


# Creating the Encoder RNN Layer
def encoder_rnn(rnn_inputs,rnn_size,num_layers,keep_prob, sequence_length):
    
    lstm = tf.contrib.rnn.BasicLSTMCell(rnn_size)
    lstm_dropout = tf.contrib.rnn.DropoutWrapper(lstm,input_keep_prob=keep_prob) 
    encoder_cell =  tf.contrib.rnn.MultiRNNCell([lstm_dropout]*num_layers) # Num. layers we plan to have
    encoder_output ,encoder_state = tf.nn.bidirectional_dynamic_rnn(cell_fw = encoder_cell,cell_bw = encoder_cell,
                                                      sequence_length = sequence_length, inputs = rnn_inputs,
                                                      dtype = tf.float32)
    return encoder_state

# Decoding the training set
def decode_training_set(encoder_state,decoder_cell,decoder_embedded_input,sequence_length, decoding_scope,
                        output_function, keep_prob, batch_size):
    
     attention_states = tf.zeros([batch_size,1,decoder_cell.output_size])
     attention_keys, attention_values, attention_score_function, attention_construct_function = tf.contrib.seq2seq.prepare_attention(attention_states,
                                                                                                                                     attention_option = "bahdanau",
                                                                                                                                     num_units = decoder_cell.output_size)
       # Attention_Keys =  That's the key is to be compared with the tarhet states
       # Attention Values = That's the values that we'll use to construct the context vectors
       ## I remind the context is returned by the enconder and that should be used by the decoder as the first element of the decoding.
       # Attention_score_function = is used to compute the similarity between the keys and the target.
       # Attention_construct_function = Functino used to build the tension state.
   
     training_decoder_function = tf.contrib.seq2seq.attention_decoder_fn_train(encoder_state[0], attention_keys, attention_values, attention_score_function, attention_construct_function, name = "attn_dec_train")
     decoder_output, decoder_final_state, decoder_final_context_state = tf.contrib.seq2seq.dynamic_rnn_decoder(decoder_cell,
                                                                                                               training_decoder_function,
                                                                                                               decoder_embedded_input,
                                                                                                               sequence_length,
                                                                                                               scope = decoding_scope) 
     decoder_output_dropout = tf.nn.dropout(decoder_output,keep_prob)
   
     return output_function(decoder_output_dropout)

# Decoding the test/validation test
     
def decode_test_set(encoder_state,decoder_cell,decoder_embeddings_matrix,sos_id,eos_id,maximum_length,
                        num_words, decoding_scope,
                        output_function, keep_prob, batch_size):
    
     attention_states = tf.zeros([batch_size,1,decoder_cell.output_size])
     attention_keys, attention_values, attention_score_function, attention_construct_function = tf.contrib.seq2seq.prepare_attention(
                                                                                                 attention_states,
                                                                                                attention_option = "bahdanau",
                                                                                                num_units = decoder_cell.output_size)
       # Attention_Keys =  That's the key is to be compared with the target states
       # Attention Values = That's the values that we'll use to construct the context vectors
       ## I remind the context is returned by the enconder and that should be used by the decoder as the first element of the decoding.
       # Attention_score_function = is used to compute the similarity between the keys and the target.
       # Attention_construct_function = Functino used to build the tension state.
   
     test_decoder_function = tf.contrib.seq2seq.attention_decoder_fn_inference(output_function,
                                                                               encoder_state[0], 
                                                                               attention_keys, 
                                                                               attention_values, 
                                                                               attention_score_function, 
                                                                               attention_construct_function, 
                                                                               decoder_embeddings_matrix,
                                                                               sos_id, eos_id, maximum_length,
                                                                               num_words,
                                                                               name = "attn_dec_inf")
  
     # Get the final output
     test_predictions,  decoder_final_state, decoder_final_context_state = tf.contrib.seq2seq.dynamic_rnn_decoder(decoder_cell,
                                                                                                                   test_decoder_function,                                                                                                         
                                                                                                                   scope = decoding_scope)

     return test_predictions

# Creating the Decoder RNN

def decoder_rnn(decoder_embedded_input, decoder_embeddings_matrix, encoder_state,num_words, sequence_length,
                rnn_size, num_layers, word2int, keep_prob, batch_size):
    
    with tf.variable_scope("decoding") as decoding_scope:
        lstm = tf.contrib.rnn.BasicLSTMCell(rnn_size)
        lstm_dropout = tf.contrib.rnn.DropoutWrapper(lstm,input_keep_prob=keep_prob) 
        decoder_cell = tf.contrib.rnn.MultiRNNCell([lstm_dropout]*num_layers) # Num. layers we plan to have
        # Initialize weights
        weights = tf.truncated_normal_initializer(stddev = 0.1) # Normal distribution of the weights
        biases = tf.zeros_initializer()
        output_function = lambda x: tf.contrib.layers.fully_connected(x,num_words,None, 
                                                                      scope = decoding_scope,
                                                                      weights_initializer = weights,
                                                                      biases_initializer = biases)
        training_predictions = decode_training_set(encoder_state,decoder_cell, decoder_embedded_input,
                                                   sequence_length,decoding_scope,output_function,keep_prob,
                                                   batch_size) # Function created up
        decoding_scope.reuse_variables()
        test_predictions = decode_test_set(encoder_state,
                                           decoder_cell,
                                           decoder_embeddings_matrix,
                                           word2int["<SOS>"],
                                           word2int["<EOS>"],
                                           sequence_length-1, # To not include the last token as we did before,
                                           num_words,
                                           decoding_scope,
                                           output_function,
                                           keep_prob,
                                           batch_size)

        return training_predictions, test_predictions
        
# Building the seq2seq model
# Brain of chatbots
def seq2seq_model(inputs, targets, keep_prob, batch_size, sequence_length, answers_num_words, questions_num_words,
                  encoder_embedding_size, decoder_embedding_size, rnn_size, num_layers,
                  questionswords2int): # inputs are the questions
    
    encoder_embedded_input = tf.contrib.layers.embed_sequence(inputs,
                                                              answers_num_words + 1,
                                                              encoder_embedding_size,
                                                              initializer = tf.random_uniform_initializer(0,1))
    
    encoder_state = encoder_rnn(encoder_embedded_input,rnn_size, num_layers,keep_prob,sequence_length)
    preprocessed_targets = preprocess_targets(targets, questionswords2int, batch_size)
    decoder_embedding_matrix = tf.Variable(tf.random_uniform([questions_num_words+1,decoder_embedding_size],0,1))
    decoder_embedded_input = tf.nn.embedding_lookup(decoder_embedding_matrix, preprocessed_targets)
    # Will' not be use for the training and that will either used for cross_validation to test the predictive power
    # of the model on new observations that won't be used to train the model more or some new predictions just to 
    # chat with the chatbot. (Above)
    training_predictions, test_predictions  = decoder_rnn(decoder_embedded_input,
                                                          decoder_embedding_matrix,
                                                          encoder_state,
                                                          questions_num_words,
                                                          sequence_length,
                                                          rnn_size,
                                                          num_layers,
                                                          questionswords2int,
                                                          keep_prob,
                                                          batch_size)
    return training_predictions, test_predictions
    
    
#%%  ############ PART 3 - Training the SEQ2SEQ Model ############
    
# Setting the Hyperparameters
    
epochs = 100 # The hole process of getting the batches of input into the network then for propagating them inside the
# encoder states then for propagating the encoder states with the targe inside the decoder record network to gen the final ouput..... A hola interection of the training
batch_size = 32
rnn_size = 1024
num_layers = 3
encoding_embedding_size = 1024
decoding_embedding_size = 1024
learning_rate = .001
learning_rate_decay = 0.9
min_learning_rate = .0001  # As learning_rate is decreacing at least has to learn this value
keep_probability = 0.5


# Defining a session

# Reset and Clean the graph
tf.reset_default_graph()
session = tf.InteractiveSession()

# Loading the model inputs

inputs, targets, lr, keep_prob  = model_input() # Function Created

# Setting the sequence length (25)
sequence_length = tf.placeholder_with_default(input = 25,shape = None, name = "sequence_length")

# Getting the shape of the inputs tensor
input_shape = tf.shape(inputs)

#%%
# Getting the training and test predeictions
training_predictions, test_predictions = seq2seq_model(tf.reverse(inputs, [-1]),
                                                       targets, 
                                                       tf.cast(keep_prob, tf.float32),
                                                       batch_size, sequence_length,
                                                       len(answerswords2int),
                                                       len(questionswords2int),
                                                       encoding_embedding_size,
                                                       decoding_embedding_size,
                                                       rnn_size,
                                                       num_layers,
                                                       questionswords2int) # Reverse the dimensions of a tensor

# Setting up the Loss Error, the optimizer and Gradient Clipping (Avoiding vanishing gradient issues)

with tf.name_scope("optimization"):
    loss_error = tf.contrib.seq2seq.sequence_loss(training_predictions,targets,
                                                  tf.ones([input_shape[0], sequence_length]))
    # Adam Optimizer
    optimizer = tf.train.AdamOptimizer(learning_rate)
    # Clip all our gradients (all neurons)
    gradients = optimizer.compute_gradients(loss_error)
    clipped_gradients = [(tf.clip_by_value(grad_tensor,-5.,5.), grad_variable) for grad_tensor,grad_variable in gradients if grad_tensor is not None] # Verify that the tensor of the gradient exists
    optimizer_gradient_clipping = optimizer.apply_gradients(clipped_gradients)
    
    
# Padding the sequence with <PAD> Token
# Question: ["who","are","you",<PAD>,<PAD>,<PAD>,<PAD>]
# Answer: [<SOS>,"I", "am","a","bot",<EOS>,<PAD>]
# Must have the same length
    
    
def apply_padding(batch_of_sequences, word2int):
    
    # Complete the sentences with path tokens
    max_sequence_length = max([len(sequences) for sequences in batch_of_sequences])
    return [sequence + [word2int["<PAD>"]]*(max_sequence_length-len(sequence)) for sequence in batch_of_sequences]
 

# Splitting the data into batches of questions and answers
    
def split_into_batches(questions, answers, batch_size):
    
    for batch_index in range(0,len(questions)//batch_size): # Gives an integer
        start_index = batch_index*batch_size
        questions_in_batch = questions[start_index:start_index + batch_size]
        answers_in_batch = answers[start_index: start_index + batch_size]
        padded_questions_in_batch = np.array(apply_padding(questions_in_batch, questionswords2int)) # Complete to have same length
        padded_answers_in_batch = np.array(apply_padding(answers_in_batch, answerswords2int)) # Complete to have same length
        
        yield padded_questions_in_batch, padded_answers_in_batch
        

# Splitting the questions and answers into training and validation sets
        
training_validation_split = int(len(sorted_clean_questions)*0.15)
training_questions = sorted_clean_questions[training_validation_split:]
training_answers = sorted_clean_answers[training_validation_split:]
validation_questions = sorted_clean_questions[:training_validation_split]
validation_answers = sorted_clean_answers[:training_validation_split]

### Training Process
batch_index_check_training_loss = 100 # Check the training loss every 100 batches
batch_index_check_validation_loss = ((len(training_questions))//batch_size// 2 ) - 1 
total_training_loss_error = 0
list_validation_loss_error = []
early_stopping_check = 0
early_stopping_stop = 100
ckeckpoint = "./chatbot_weights.ckpt" # File containing the weights
session.run(tf.global_variables_initializer())

for epoch in range(1,epochs+1):
    for batch_index, (padded_questions_in_batch, padded_answers_in_batch) in enumerate(split_into_batches(training_questions,training_answers, batch_size)):
        starting_time = time.time()
        _, batch_training_loss_error = session.run([optimizer_gradient_clipping, loss_error], {inputs: padded_questions_in_batch,
                                                                                               targets: padded_answers_in_batch,
                                                                                               lr: learning_rate,
                                                                                               sequence_length: padded_answers_in_batch.shape[1],
                                                                                               keep_prob: keep_probability})
    
    
        total_training_loss_error += batch_training_loss_error
        ending_time = time.time()
        batch_time = ending_time - starting_time
        
        if batch_index % batch_index_check_training_loss==0: # Every 100
            print("Epoch No. {:>3}/{}, Batch: {:>4}/{} , Training Loss Error : {:>6.3f}, Training_Time on 100 Batches {:d} Seconds".format(epoch,
                                                                                                                       epochs,
                                                                                                                       batch_index,
                                                                                                                       len(training_questions)//batch_size,
                                                                                                                       total_training_loss_error/batch_index_check_training_loss,
                                                                                                                       int(batch_time * batch_index_check_training_loss)))                                                                                                                              
            total_training_loss_error = 0
            
        if batch_index % batch_index_check_validation_loss ==0 and batch_index >0:
            total_validation_loss_error = 0
            starting_time = time.time()
            
            for batch_index_validation, (padded_questions_in_batch, padded_answers_in_batch) in enumerate(split_into_batches(validation_questions,validation_answers, batch_size)):
                batch_validation_loss_error = session.run(loss_error, {inputs: padded_questions_in_batch,
                                                                       targets: padded_answers_in_batch,
                                                                       lr: learning_rate,
                                                                       sequence_length: padded_answers_in_batch.shape[1],
                                                                       keep_prob: 1 }) # Validation
    
            
                total_validation_loss_error += batch_validation_loss_error
            ending_time = time.time()
            batch_time = ending_time - starting_time
            average_validation_loss_error = total_validation_loss_error / (len(validation_questions)/ batch_size) # Gives the Number of batches in the validation set
            print("Validation Loss Error: {:>6.3f}, Batch Validation Time: {:d} Seconds".format(average_validation_loss_error, int(batch_time)))
            learning_rate *= learning_rate_decay
            
            if learning_rate< min_learning_rate:
                learning_rate = min_learning_rate
                
            list_validation_loss_error.append(average_validation_loss_error)
            
            if average_validation_loss_error <= min(list_validation_loss_error):
                print("I speak better now")
                early_stopping_check = 0 # Only Increase when there's no improvement in the validation loss error
                saver = tf.train.Saver()
                saver.save(session, ckeckpoint) # Save the model
                
            else:
                print("Sorry, I do not speak better. I need to practice more")
                early_stopping_check +=1
                
                if early_stopping_check == early_stopping_stop: # If it reaches the maximum iteration
                    break
    
    if early_stopping_check == early_stopping_stop:
        print("My Apologies, I cannot speak better anymore. This is the best I can do.")
        break
    
print("Game Over")


#%% ################ PART 4 - TESTING THE SEQ2SEQ MODEL ################

# Loading the weights and Running the session
checkpoint = "./chatbot_weights.ckpt"
session = tf.InteractiveSession()
session.run(tf.global_variables_initializer())
saver = tf.train.Saver()
saver.restore(session, checkpoint)

# Converting the questions from strings to list of encoding integers
def convert_string2int(question,word2int):
    question = clean_text(question)
    return [word2int.get(word,word2int["<OUT>"]) for word in question.split()]
    # if the word does not exit in the dictiona, it'll return word2int["<OUT>"]
    
# Setting up the chat
while True:
    question = input("You speak : ")
    if question=="GoodBye" or question=="goodBye" or question=="Goodbye" or question=="goodbye":
        break
    # Make all the process of getting the question in the right format
    question = convert_string2int(question,questionswords2int)
    # Complete the length of the question (15)
    if len(question)<25:
        question = question + [questionswords2int["<PAD>"]]*(25-len(question))
    else:
        while len(question)>25:
             done = False
             question = input("You speak (less than 25 words) : ")
             if question=="GoodBye" or question=="goodBye" or question=="Goodbye" or question=="goodbye":
                 done = True
                 break
        if done:
            break
        question = convert_string2int(question,questionswords2int)
        question = question + [questionswords2int["<PAD>"]]*(25-len(question))   
        
    fake_batch = np.zeros((batch_size,25))
    fake_batch[0] = question
    predicted_answer = session.run(test_predictions,{inputs:fake_batch,keep_prob:0.5})[0]
    answer = ""
    for i in np.argmax(predicted_answer,1):
        if answerints2word[i]== "i":
            token = "I"
        elif answerints2word[i]=="<EOS>":
            token = "."
        elif answerints2word[i]=="<OUT>":
            token = "out"
        else:
            token = " " + answerints2word[i] 
            
        answer += token
        
        if token == ".": # The Chatbot is done talking (it can be more spaces but they're just are the spaces that were
            # filled to process the question)
            break
    print(" Chatbot Says : {} ".format(answer))
            
    
            
















